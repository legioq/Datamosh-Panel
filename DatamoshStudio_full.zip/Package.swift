// swift-tools-version:5.7
import PackageDescription

let package = Package(
    name: "DatamoshStudio",
    platforms: [
        .macOS(.v12)
    ],
    products: [
        .executable(name: "DatamoshStudio", targets: ["DatamoshStudio"]),
    ],
    dependencies: [],
    targets: [
        .executableTarget(
            name: "DatamoshStudio",
            path: "Sources/DatamoshStudio",
            resources: [
                .copy("../Resources")
            ]
        )
    ]
)
