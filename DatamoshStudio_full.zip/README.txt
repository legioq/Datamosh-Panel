DatamoshStudio - macOS App (Swift + AppKit + Metal + FFmpeg)
---------------------------------------------------------

What is included:
- Swift Package layout (open Package.swift in Xcode)
- Sources with AppDelegate.swift and ViewController.swift (AppKit UI: buttons, progress, drag-and-drop)
- Metal shader (simple glitch/pixel shader template)
- FFmpeg wrapper script (ffmpeg must be installed via Homebrew)
- Packaging script make_pkg.sh to create .pkg installer (uses pkgbuild/productbuild)
- build_universal.sh script showing how to build a universal .app using xcodebuild

Quick start:
1) Install ffmpeg: `brew install ffmpeg`
2) Open `Package.swift` in Xcode (File → Open) — Xcode will create a project workspace.
3) Select My Mac (Any) and build the executable target (Cmd+B). To create .app, choose "Product → Archive" or use Xcode to create a macOS App target if you prefer an .app wrapper.
4) Run `Scripts/build_universal.sh` to build universal binaries (script prints recommended commands).
5) After you have DatamoshStudio.app in build/Release, run `Packaging/make_pkg.sh` to create DatamoshStudio-Installer.pkg

Files created in this package:
- Sources/DatamoshStudio/*.swift
- Resources/Shaders/glitch.metal
- Scripts/ffmpeg_datamosh.sh  (helper wrapper to run ffmpeg datamosh flow)
- Scripts/build_universal.sh
- Packaging/make_pkg.sh

Note: This template uses external ffmpeg; Metal shader integration is provided as starting point.
