#!/usr/bin/env bash
# build_universal.sh
echo "To build universal app, open Package.swift in Xcode and build for 'Any Mac'."
echo "If you have an Xcode project, you can archive for each arch and lipo them together."
echo "Example (requires xcodeproj):"
echo "xcodebuild -project DatamoshStudio.xcodeproj -scheme DatamoshStudio -configuration Release -arch arm64 BUILD_DIR=build/arm64"
echo "xcodebuild -project DatamoshStudio.xcodeproj -scheme DatamoshStudio -configuration Release -arch x86_64 BUILD_DIR=build/x86_64"
echo "lipo -create build/arm64/Release/DatamoshStudio build/x86_64/Release/DatamoshStudio -output build/Release/DatamoshStudio_universal"
