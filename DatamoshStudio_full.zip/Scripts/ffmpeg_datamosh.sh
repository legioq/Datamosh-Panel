#!/usr/bin/env bash
# ffmpeg_datamosh.sh
# Usage: ffmpeg_datamosh.sh input.mp4 output.mp4
set -e
if [ $# -lt 2 ]; then
  echo "Usage: $0 input output"
  exit 1
fi
IN="$1"; OUT="$2"
TMPDIR=$(mktemp -d)
PARTA="$TMPDIR/partA.mp4"
PARTB="$TMPDIR/partB.mp4"
LIST="$TMPDIR/list.txt"

# locate ffmpeg (both Intel and Apple Silicon Homebrew paths)
if [ -x "/usr/local/bin/ffmpeg" ]; then
  FFMPEG="/usr/local/bin/ffmpeg"
elif [ -x "/opt/homebrew/bin/ffmpeg" ]; then
  FFMPEG="/opt/homebrew/bin/ffmpeg"
else
  echo "ffmpeg not found. Install with: brew install ffmpeg"
  exit 2
fi

echo "Creating part A (normal keyframes)..."
"$FFMPEG" -y -i "$IN" -c:v libx264 -preset veryfast -g 250 -keyint_min 25 -sc_threshold 0 -an "$PARTA"

echo "Creating part B (long GOP, datamosh)..."
"$FFMPEG" -y -i "$IN" -c:v libx264 -preset veryfast -g 9999 -keyint_min 9999 -sc_threshold 0 -an "$PARTB"

echo "Concatenating..."
printf "file '%s'\nfile '%s'\n" "$PARTA" "$PARTB" > "$LIST"
"$FFMPEG" -y -f concat -safe 0 -i "$LIST" -c copy "$OUT"

echo "Result: $OUT"
rm -rf "$TMPDIR"
