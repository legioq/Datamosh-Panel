import Cocoa
import MetalKit

class ViewController: NSViewController {
    // UI elements
    let selectButton = NSButton(title: "Select Video...", target: nil, action: nil)
    let moshButton = NSButton(title: "Apply Datamosh", target: nil, action: nil)
    let progress = NSProgressIndicator()
    let statusLabel = NSTextField(labelWithString: "Ready")
    let dropLabel = NSTextField(labelWithString: "Drag & Drop video file here")
    let pixelateCheckbox = NSButton(checkboxWithTitle: "Pixelate", target: nil, action: nil)
    let glitchCheckbox = NSButton(checkboxWithTitle: "Glitch shader", target: nil, action: nil)
    let datamoshCheckbox = NSButton(checkboxWithTitle: "Datamosh (long GOP)", target: nil, action: nil)
    let hardBreakCheckbox = NSButton(checkboxWithTitle: "I-frame break (sharp)", target: nil, action: nil)
    let formatPopup = NSPopUpButton()

    var inputURL: URL? { didSet { updateUI() } }

    // Metal
    var mtkView: MTKView?
    var device: MTLDevice?
    var commandQueue: MTLCommandQueue?

    override func loadView() {
        view = NSView()
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        setupUI()
        setupMetal()
    }

    func setupUI() {
        selectButton.target = self; selectButton.action = #selector(selectFile)
        moshButton.target = self; moshButton.action = #selector(applyEffects)
        formatPopup.addItems(withTitles: ["mov (prores)","mp4 (h264)","mkv (h264)"])

        progress.minValue = 0; progress.maxValue = 1; progress.doubleValue = 0
        statusLabel.lineBreakMode = .byTruncatingTail

        // layout
        let vstack = NSStackView()
        vstack.orientation = .vertical
        vstack.spacing = 10
        vstack.translatesAutoresizingMaskIntoConstraints = false

        vstack.addArrangedSubview(selectButton)
        vstack.addArrangedSubview(dropLabel)
        vstack.addArrangedSubview(pixelateCheckbox)
        vstack.addArrangedSubview(glitchCheckbox)
        vstack.addArrangedSubview(datamoshCheckbox)
        vstack.addArrangedSubview(hardBreakCheckbox)
        vstack.addArrangedSubview(formatPopup)
        vstack.addArrangedSubview(moshButton)
        vstack.addArrangedSubview(progress)
        vstack.addArrangedSubview(statusLabel)

        view.addSubview(vstack)
        NSLayoutConstraint.activate([
            vstack.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 20),
            vstack.topAnchor.constraint(equalTo: view.topAnchor, constant: 20),
            vstack.widthAnchor.constraint(equalToConstant: 320)
        ])

        // Drag & drop
        view.registerForDraggedTypes([.fileURL])
    }

    func setupMetal() {
        device = MTLCreateSystemDefaultDevice()
        guard let device = device else { return }
        commandQueue = device.makeCommandQueue()
        let mtk = MTKView(frame: .zero, device: device)
        mtk.translatesAutoresizingMaskIntoConstraints = false
        view.addSubview(mtk)
        NSLayoutConstraint.activate([
            mtk.trailingAnchor.constraint(equalTo: view.trailingAnchor, constant: -20),
            mtk.topAnchor.constraint(equalTo: view.topAnchor, constant: 20),
            mtk.bottomAnchor.constraint(equalTo: view.bottomAnchor, constant: -20),
            mtk.leadingAnchor.constraint(equalTo: view.leadingAnchor, constant: 360)
        ])
        mtkView = mtk
    }

    func updateUI() {
        moshButton.isEnabled = (inputURL != nil)
        if let url = inputURL {
            statusLabel.stringValue = "Selected: \(url.lastPathComponent)"
        } else {
            statusLabel.stringValue = "Ready"
        }
    }

    @objc func selectFile() {
        let panel = NSOpenPanel()
        panel.allowedContentTypes = [.movie]
        panel.allowsMultipleSelection = false
        panel.begin { resp in
            if resp == .OK { self.inputURL = panel.url }
        }
    }

    @objc func applyEffects() {
        guard let inURL = inputURL else { return }
        statusLabel.stringValue = "Processing..."
        progress.doubleValue = 0.1

        // Build ffmpeg command
        let tmp = FileManager.default.temporaryDirectory
        let partA = tmp.appendingPathComponent("mosh_A.mp4")
        let partB = tmp.appendingPathComponent("mosh_B.mp4")
        let result = inURL.deletingPathExtension().appendingPathExtension("moshed.mp4")

        DispatchQueue.global().async {
            // Part A normal
            var cmdA = ["-y", "-i", inURL.path]
            if self.pixelateCheckbox.state == .on {
                cmdA += ["-vf", "scale=iw/10:ih/10:flags=neighbor,scale=iw:ih:flags=neighbor"]
            }
            cmdA += ["-c:v","libx264","-preset","veryfast","-g","250", partA.path]

            // Part B long GOP
            var cmdB = ["-y", "-i", inURL.path]
            if self.pixelateCheckbox.state == .on {
                cmdB += ["-vf", "scale=iw/10:ih/10:flags=neighbor,scale=iw:ih:flags=neighbor"]
            }
            # long GOP for datamosh
            cmdB += ["-c:v","libx264","-preset","veryfast","-g","9999","-keyint_min","9999","-sc_threshold","0", partB.path]

            // execute
            let okA = self.runFFmpeg(arguments: cmdA)
            DispatchQueue.main.async { self.progress.doubleValue = 0.4 }
            let okB = self.runFFmpeg(arguments: cmdB)
            DispatchQueue.main.async { self.progress.doubleValue = 0.8 }

            if okA && okB {
                // concat
                let list = tmp.appendingPathComponent("mosh_list.txt")
                let listContent = "file '\(partA.path)'\nfile '\(partB.path)'\n"
                try? listContent.write(to: list, atomically: true, encoding: .utf8)
                let concatArgs = ["-y","-f","concat","-safe","0","-i", list.path, "-c","copy", result.path]
                let okC = self.runFFmpeg(arguments: concatArgs)
                DispatchQueue.main.async {
                    if okC {
                        self.statusLabel.stringValue = "Saved: \(result.lastPathComponent)"
                        self.progress.doubleValue = 1.0
                    } else {
                        self.statusLabel.stringValue = "Concat failed"
                    }
                }
            } else {
                DispatchQueue.main.async {
                    self.statusLabel.stringValue = "Encoding failed"
                    self.progress.doubleValue = 0
                }
            }
        }
    }

    func runFFmpeg(arguments: [String]) -> Bool {
        // ffmpeg must be installed (brew install ffmpeg)
        let ffmpeg = "/usr/local/bin/ffmpeg"
        let alt = "/opt/homebrew/bin/ffmpeg" // Apple Silicon Homebrew default
        let ff = FileManager.default.isExecutableFile(atPath: ffmpeg) ? ffmpeg : (FileManager.default.isExecutableFile(atPath: alt) ? alt : nil)
        guard let ffPath = ff else {
            DispatchQueue.main.async { self.statusLabel.stringValue = "ffmpeg not found. Install via Homebrew." }
            return false
        }

        let process = Process()
        process.launchPath = ffPath
        process.arguments = arguments
        let pipe = Pipe()
        process.standardError = pipe
        process.standardOutput = Pipe()
        do {
            try process.run()
        } catch {
            return false
        }
        process.waitUntilExit()
        return process.terminationStatus == 0
    }

    // Drag & drop handling
    override func draggingEntered(_ sender: NSDraggingInfo) -> NSDragOperation {
        return .copy
    }

    override func performDragOperation(_ sender: NSDraggingInfo) -> Bool {
        let pb = sender.draggingPasteboard
        if let urls = pb.readObjects(forClasses: [NSURL.self], options: nil) as? [URL], let first = urls.first {
            self.inputURL = first
            return true
        }
        return false
    }
}
