#!/usr/bin/env bash
set -e
# Usage: Packaging/make_pkg.sh /path/to/DatamoshStudio.app
if [ $# -lt 1 ]; then
  echo "Usage: $0 /path/to/DatamoshStudio.app"
  exit 1
fi
APP_PATH="$1"
if [ ! -d "$APP_PATH" ]; then
  echo "App not found: $APP_PATH"
  exit 2
fi
PKGROOT="pkgroot"
PKGNAME="DatamoshStudio.pkg"
OUTPKG="DatamoshStudio-Installer.pkg"

rm -rf "$PKGROOT"
mkdir -p "$PKGROOT/Applications"
cp -R "$APP_PATH" "$PKGROOT/Applications/"

pkgbuild --root "$PKGROOT" --identifier "com.example.datamosh" --version "1.0" --install-location "/" "$PKGNAME"
productbuild --package "$PKGNAME" "$OUTPKG"
echo "Created: $OUTPKG"
